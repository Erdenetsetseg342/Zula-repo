﻿namespace UrbanVogue_OnlineShop
{
    partial class Zahlung
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            VogueLabel = new Label();
            label1 = new Label();
            labelWarenkorb = new Label();
            listBoxWarenkorb = new ListBox();
            button1 = new Button();
            buttonUEberUns = new Button();
            buttonMeinKonto = new Button();
            buttonEinkaufskorb = new Button();
            buttonKasse = new Button();
            SuspendLayout();
            // 
            // VogueLabel
            // 
            VogueLabel.AutoSize = true;
            VogueLabel.Font = new Font("Bell MT", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            VogueLabel.Location = new Point(77, 79);
            VogueLabel.Name = "VogueLabel";
            VogueLabel.Size = new Size(112, 41);
            VogueLabel.TabIndex = 5;
            VogueLabel.Text = "Vogue";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Bell MT", 20F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(46, 42);
            label1.Name = "label1";
            label1.Size = new Size(125, 46);
            label1.TabIndex = 4;
            label1.Text = "Urban";
            // 
            // labelWarenkorb
            // 
            labelWarenkorb.AutoSize = true;
            labelWarenkorb.Font = new Font("Bell MT", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            labelWarenkorb.Location = new Point(62, 184);
            labelWarenkorb.Name = "labelWarenkorb";
            labelWarenkorb.Size = new Size(127, 27);
            labelWarenkorb.TabIndex = 6;
            labelWarenkorb.Text = "Warenkorb";
            // 
            // listBoxWarenkorb
            // 
            listBoxWarenkorb.BackColor = SystemColors.ControlLight;
            listBoxWarenkorb.FormattingEnabled = true;
            listBoxWarenkorb.ItemHeight = 25;
            listBoxWarenkorb.Location = new Point(62, 250);
            listBoxWarenkorb.Name = "listBoxWarenkorb";
            listBoxWarenkorb.Size = new Size(767, 179);
            listBoxWarenkorb.TabIndex = 7;
            listBoxWarenkorb.SelectedIndexChanged += listBoxWarenkorb_SelectedIndexChanged;
            // 
            // button1
            // 
            button1.BackColor = SystemColors.ControlLight;
            button1.Font = new Font("Bell MT", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button1.Location = new Point(64, 712);
            button1.Name = "button1";
            button1.Size = new Size(125, 33);
            button1.TabIndex = 15;
            button1.Text = "Impressum";
            button1.UseVisualStyleBackColor = false;
            // 
            // buttonUEberUns
            // 
            buttonUEberUns.BackColor = SystemColors.ControlLight;
            buttonUEberUns.Font = new Font("Bell MT", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            buttonUEberUns.Location = new Point(64, 673);
            buttonUEberUns.Name = "buttonUEberUns";
            buttonUEberUns.Size = new Size(125, 33);
            buttonUEberUns.TabIndex = 14;
            buttonUEberUns.Text = "Über uns";
            buttonUEberUns.UseVisualStyleBackColor = false;
            // 
            // buttonMeinKonto
            // 
            buttonMeinKonto.BackColor = SystemColors.ControlLight;
            buttonMeinKonto.Font = new Font("Bell MT", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            buttonMeinKonto.Location = new Point(673, 55);
            buttonMeinKonto.Name = "buttonMeinKonto";
            buttonMeinKonto.Size = new Size(158, 33);
            buttonMeinKonto.TabIndex = 17;
            buttonMeinKonto.Text = "MEIN KONTO";
            buttonMeinKonto.UseVisualStyleBackColor = false;
            // 
            // buttonEinkaufskorb
            // 
            buttonEinkaufskorb.BackColor = SystemColors.ControlLight;
            buttonEinkaufskorb.Font = new Font("Bell MT", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            buttonEinkaufskorb.Location = new Point(868, 55);
            buttonEinkaufskorb.Name = "buttonEinkaufskorb";
            buttonEinkaufskorb.Size = new Size(158, 33);
            buttonEinkaufskorb.TabIndex = 16;
            buttonEinkaufskorb.Text = "EINKAUFSKORB";
            buttonEinkaufskorb.UseVisualStyleBackColor = false;
            // 
            // buttonKasse
            // 
            buttonKasse.BackColor = SystemColors.ControlLight;
            buttonKasse.Font = new Font("Bell MT", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            buttonKasse.Location = new Point(64, 483);
            buttonKasse.Name = "buttonKasse";
            buttonKasse.Size = new Size(158, 33);
            buttonKasse.TabIndex = 18;
            buttonKasse.Text = "Zur Kasse";
            buttonKasse.UseVisualStyleBackColor = false;
            buttonKasse.Click += buttonKasse_Click;
            // 
            // Zahlung
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ControlLight;
            ClientSize = new Size(1084, 777);
            Controls.Add(buttonKasse);
            Controls.Add(buttonMeinKonto);
            Controls.Add(buttonEinkaufskorb);
            Controls.Add(button1);
            Controls.Add(buttonUEberUns);
            Controls.Add(listBoxWarenkorb);
            Controls.Add(labelWarenkorb);
            Controls.Add(VogueLabel);
            Controls.Add(label1);
            Name = "Zahlung";
            Text = "Zahlung";
            Load += Zahlung_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label VogueLabel;
        private Label label1;
        private Label labelWarenkorb;
        private ListBox listBoxWarenkorb;
        private Button button1;
        private Button buttonUEberUns;
        private Button buttonMeinKonto;
        private Button buttonEinkaufskorb;
        private Button buttonKasse;
    }
}