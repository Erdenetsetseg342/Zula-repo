﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UrbanVogue_OnlineShop
{
    public class Benutzer
    {
        public int BenutzerID { get; set; }
        public string Name { get; set; }
        public string Adresse { get; set; }
        public string Email { get; set; }
       
        public string Passwort { get; set; }

        // Konstruktor mit Initialisierung
        public Benutzer(int benutzerID, string name, string adress, string email, string passwort)
        {
            BenutzerID = benutzerID;
            Name = name;
            Adresse = adress;
            Email = email;
            Passwort = passwort; // Jetzt wird Passwort immer gesetzt
        }
    }

}


