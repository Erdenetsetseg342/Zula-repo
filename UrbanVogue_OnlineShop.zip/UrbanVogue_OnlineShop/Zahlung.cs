﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UrbanVogue_OnlineShop
{
    public partial class Zahlung : Form
    {

        public Zahlung(List<string> warenkorbListe)
        {
            InitializeComponent();
            //Warenkorb Produkte in die ListBox Laden
            foreach (string produkt in warenkorbListe)
            {
                listBoxWarenkorb.Items.Add(produkt);
            }
        }

        private void Zahlung_Load(object sender, EventArgs e)
        {

        }

        private void listBoxWarenkorb_SelectedIndexChanged(object sender, EventArgs e)
        {
            listBoxWarenkorb.Items.Clear();
        }

        private void buttonKasse_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Weiter zur Kasse!", "Kasse", MessageBoxButtons.OK, MessageBoxIcon.Information);
            this.Close();
        }
    }
}
