﻿namespace UrbanVogue_OnlineShop
{
    partial class Hauptfenster
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            VogueLabel = new Label();
            labelAnmelden = new Label();
            buttonEinkaufskorb = new Button();
            buttonMeinKonto = new Button();
            labelBenutzer = new Label();
            labelPasswort = new Label();
            textBoxBenutzer = new TextBox();
            textBoxPasswort = new TextBox();
            buttonAnmelden = new Button();
            buttonUEberUns = new Button();
            buttonImpressum = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Bell MT", 20F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(61, 61);
            label1.Name = "label1";
            label1.Size = new Size(125, 46);
            label1.TabIndex = 0;
            label1.Text = "Urban";
            // 
            // VogueLabel
            // 
            VogueLabel.AutoSize = true;
            VogueLabel.Font = new Font("Bell MT", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            VogueLabel.Location = new Point(92, 98);
            VogueLabel.Name = "VogueLabel";
            VogueLabel.Size = new Size(112, 41);
            VogueLabel.TabIndex = 1;
            VogueLabel.Text = "Vogue";
            // 
            // labelAnmelden
            // 
            labelAnmelden.AutoSize = true;
            labelAnmelden.Font = new Font("Bell MT", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
            labelAnmelden.Location = new Point(91, 253);
            labelAnmelden.Name = "labelAnmelden";
            labelAnmelden.Size = new Size(126, 23);
            labelAnmelden.TabIndex = 2;
            labelAnmelden.Text = "ANMELDEN";
            // 
            // buttonEinkaufskorb
            // 
            buttonEinkaufskorb.BackColor = SystemColors.ControlLight;
            buttonEinkaufskorb.Font = new Font("Bell MT", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            buttonEinkaufskorb.Location = new Point(790, 98);
            buttonEinkaufskorb.Name = "buttonEinkaufskorb";
            buttonEinkaufskorb.Size = new Size(158, 33);
            buttonEinkaufskorb.TabIndex = 3;
            buttonEinkaufskorb.Text = "EINKAUFSKORB";
            buttonEinkaufskorb.UseVisualStyleBackColor = false;
            // 
            // buttonMeinKonto
            // 
            buttonMeinKonto.BackColor = SystemColors.ControlLight;
            buttonMeinKonto.Font = new Font("Bell MT", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            buttonMeinKonto.Location = new Point(611, 98);
            buttonMeinKonto.Name = "buttonMeinKonto";
            buttonMeinKonto.Size = new Size(158, 33);
            buttonMeinKonto.TabIndex = 4;
            buttonMeinKonto.Text = "MEIN KONTO";
            buttonMeinKonto.UseVisualStyleBackColor = false;
            // 
            // labelBenutzer
            // 
            labelBenutzer.AutoSize = true;
            labelBenutzer.Font = new Font("Bell MT", 8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            labelBenutzer.Location = new Point(91, 339);
            labelBenutzer.Name = "labelBenutzer";
            labelBenutzer.Size = new Size(145, 18);
            labelBenutzer.TabIndex = 6;
            labelBenutzer.Text = "BENUTZERNAME";
            // 
            // labelPasswort
            // 
            labelPasswort.AutoSize = true;
            labelPasswort.Font = new Font("Bell MT", 8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            labelPasswort.Location = new Point(92, 426);
            labelPasswort.Name = "labelPasswort";
            labelPasswort.Size = new Size(95, 18);
            labelPasswort.TabIndex = 7;
            labelPasswort.Text = "PASSWORT";
            // 
            // textBoxBenutzer
            // 
            textBoxBenutzer.BackColor = SystemColors.ButtonFace;
            textBoxBenutzer.Location = new Point(92, 305);
            textBoxBenutzer.Name = "textBoxBenutzer";
            textBoxBenutzer.Size = new Size(321, 31);
            textBoxBenutzer.TabIndex = 8;
            // 
            // textBoxPasswort
            // 
            textBoxPasswort.BackColor = SystemColors.ButtonFace;
            textBoxPasswort.Location = new Point(92, 392);
            textBoxPasswort.Name = "textBoxPasswort";
            textBoxPasswort.Size = new Size(321, 31);
            textBoxPasswort.TabIndex = 9;
            // 
            // buttonAnmelden
            // 
            buttonAnmelden.BackColor = SystemColors.ControlLight;
            buttonAnmelden.Font = new Font("Bell MT", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            buttonAnmelden.Location = new Point(91, 506);
            buttonAnmelden.Name = "buttonAnmelden";
            buttonAnmelden.Size = new Size(158, 33);
            buttonAnmelden.TabIndex = 10;
            buttonAnmelden.Text = "ANMELDEN";
            buttonAnmelden.UseVisualStyleBackColor = false;
            buttonAnmelden.Click += buttonAnmelden_Click;
            // 
            // buttonUEberUns
            // 
            buttonUEberUns.BackColor = SystemColors.ControlLight;
            buttonUEberUns.Font = new Font("Bell MT", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            buttonUEberUns.Location = new Point(92, 673);
            buttonUEberUns.Name = "buttonUEberUns";
            buttonUEberUns.Size = new Size(125, 33);
            buttonUEberUns.TabIndex = 11;
            buttonUEberUns.Text = "Über uns";
            buttonUEberUns.UseVisualStyleBackColor = false;
            buttonUEberUns.Click += buttonUEberUns_Click;
            // 
            // buttonImpressum
            // 
            buttonImpressum.BackColor = SystemColors.ControlLight;
            buttonImpressum.Font = new Font("Bell MT", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            buttonImpressum.Location = new Point(92, 712);
            buttonImpressum.Name = "buttonImpressum";
            buttonImpressum.Size = new Size(125, 33);
            buttonImpressum.TabIndex = 12;
            buttonImpressum.Text = "Impressum";
            buttonImpressum.UseVisualStyleBackColor = false;
            buttonImpressum.Click += buttonImpressum_Click;
            // 
            // Hauptfenster
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ControlLight;
            ClientSize = new Size(1023, 792);
            Controls.Add(buttonImpressum);
            Controls.Add(buttonUEberUns);
            Controls.Add(buttonAnmelden);
            Controls.Add(textBoxPasswort);
            Controls.Add(textBoxBenutzer);
            Controls.Add(labelPasswort);
            Controls.Add(labelBenutzer);
            Controls.Add(buttonMeinKonto);
            Controls.Add(buttonEinkaufskorb);
            Controls.Add(labelAnmelden);
            Controls.Add(VogueLabel);
            Controls.Add(label1);
            Name = "Hauptfenster";
            Text = "Hauptfenster";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label VogueLabel;
        private Label labelAnmelden;
        private Button buttonEinkaufskorb;
        private Button buttonMeinKonto;
        private Label labelBenutzer;
        private Label labelPasswort;
        private TextBox textBoxBenutzer;
        private TextBox textBoxPasswort;
        private Button buttonAnmelden;
        private Button buttonUEberUns;
        private Button buttonImpressum;
    }
}
