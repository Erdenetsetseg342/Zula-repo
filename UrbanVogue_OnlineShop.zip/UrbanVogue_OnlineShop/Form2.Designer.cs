﻿namespace UrbanVogue_OnlineShop
{
    partial class WebsideFenster
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            VogueLabel = new Label();
            label1 = new Label();
            buttonEinkaufskorb = new Button();
            buttonMeinKonto = new Button();
            buttonUEberUns = new Button();
            button1 = new Button();
            buttonDamen = new Button();
            buttonHerren = new Button();
            buttonKinder = new Button();
            buttonTheNew = new Button();
            buttonKleider = new Button();
            buttonJeans = new Button();
            buttonJacken = new Button();
            buttonHemden = new Button();
            buttonAccessoires = new Button();
            pictureBox1 = new PictureBox();
            pictureBox2 = new PictureBox();
            pictureBox3 = new PictureBox();
            pictureBox4 = new PictureBox();
            pictureBox5 = new PictureBox();
            pictureBox6 = new PictureBox();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            button11 = new Button();
            buttonKaufen = new Button();
            buttonKaufen1 = new Button();
            buttonKaufen2 = new Button();
            buttonKaufen3 = new Button();
            buttonKaufen4 = new Button();
            buttonKaufen5 = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            SuspendLayout();
            // 
            // VogueLabel
            // 
            VogueLabel.AutoSize = true;
            VogueLabel.Font = new Font("Bell MT", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            VogueLabel.Location = new Point(80, 54);
            VogueLabel.Name = "VogueLabel";
            VogueLabel.Size = new Size(112, 41);
            VogueLabel.TabIndex = 3;
            VogueLabel.Text = "Vogue";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Bell MT", 20F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(49, 17);
            label1.Name = "label1";
            label1.Size = new Size(125, 46);
            label1.TabIndex = 2;
            label1.Text = "Urban";
            // 
            // buttonEinkaufskorb
            // 
            buttonEinkaufskorb.BackColor = SystemColors.ControlLight;
            buttonEinkaufskorb.Font = new Font("Bell MT", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            buttonEinkaufskorb.Location = new Point(861, 30);
            buttonEinkaufskorb.Name = "buttonEinkaufskorb";
            buttonEinkaufskorb.Size = new Size(158, 33);
            buttonEinkaufskorb.TabIndex = 4;
            buttonEinkaufskorb.Text = "EINKAUFSKORB";
            buttonEinkaufskorb.UseVisualStyleBackColor = false;
            buttonEinkaufskorb.Click += buttonEinkaufskorb_Click;
            // 
            // buttonMeinKonto
            // 
            buttonMeinKonto.BackColor = SystemColors.ControlLight;
            buttonMeinKonto.Font = new Font("Bell MT", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            buttonMeinKonto.Location = new Point(666, 30);
            buttonMeinKonto.Name = "buttonMeinKonto";
            buttonMeinKonto.Size = new Size(158, 33);
            buttonMeinKonto.TabIndex = 5;
            buttonMeinKonto.Text = "MEIN KONTO";
            buttonMeinKonto.UseVisualStyleBackColor = false;
            // 
            // buttonUEberUns
            // 
            buttonUEberUns.BackColor = SystemColors.ControlLight;
            buttonUEberUns.Font = new Font("Bell MT", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            buttonUEberUns.Location = new Point(67, 614);
            buttonUEberUns.Name = "buttonUEberUns";
            buttonUEberUns.Size = new Size(125, 33);
            buttonUEberUns.TabIndex = 12;
            buttonUEberUns.Text = "Über uns";
            buttonUEberUns.UseVisualStyleBackColor = false;
            // 
            // button1
            // 
            button1.BackColor = SystemColors.ControlLight;
            button1.Font = new Font("Bell MT", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button1.Location = new Point(67, 653);
            button1.Name = "button1";
            button1.Size = new Size(125, 33);
            button1.TabIndex = 13;
            button1.Text = "Impressum";
            button1.UseVisualStyleBackColor = false;
            // 
            // buttonDamen
            // 
            buttonDamen.BackColor = SystemColors.ControlLight;
            buttonDamen.Font = new Font("Bell MT", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            buttonDamen.Location = new Point(58, 111);
            buttonDamen.Name = "buttonDamen";
            buttonDamen.Size = new Size(125, 33);
            buttonDamen.TabIndex = 14;
            buttonDamen.Text = "Damen";
            buttonDamen.UseVisualStyleBackColor = false;
            buttonDamen.Click += buttonDamen_Click;
            // 
            // buttonHerren
            // 
            buttonHerren.BackColor = SystemColors.ControlLight;
            buttonHerren.Font = new Font("Bell MT", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            buttonHerren.Location = new Point(235, 111);
            buttonHerren.Name = "buttonHerren";
            buttonHerren.Size = new Size(125, 33);
            buttonHerren.TabIndex = 15;
            buttonHerren.Text = "Herren";
            buttonHerren.UseVisualStyleBackColor = false;
            // 
            // buttonKinder
            // 
            buttonKinder.BackColor = SystemColors.ControlLight;
            buttonKinder.Font = new Font("Bell MT", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            buttonKinder.Location = new Point(411, 111);
            buttonKinder.Name = "buttonKinder";
            buttonKinder.Size = new Size(125, 33);
            buttonKinder.TabIndex = 16;
            buttonKinder.Text = "Kinder";
            buttonKinder.UseVisualStyleBackColor = false;
            // 
            // buttonTheNew
            // 
            buttonTheNew.BackColor = SystemColors.ControlLight;
            buttonTheNew.Font = new Font("Bell MT", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            buttonTheNew.Location = new Point(58, 183);
            buttonTheNew.Name = "buttonTheNew";
            buttonTheNew.Size = new Size(125, 33);
            buttonTheNew.TabIndex = 17;
            buttonTheNew.Text = "The New";
            buttonTheNew.UseVisualStyleBackColor = false;
            // 
            // buttonKleider
            // 
            buttonKleider.BackColor = SystemColors.ControlLight;
            buttonKleider.Font = new Font("Bell MT", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            buttonKleider.Location = new Point(58, 222);
            buttonKleider.Name = "buttonKleider";
            buttonKleider.Size = new Size(125, 33);
            buttonKleider.TabIndex = 18;
            buttonKleider.Text = "Kleider";
            buttonKleider.UseVisualStyleBackColor = false;
            // 
            // buttonJeans
            // 
            buttonJeans.BackColor = SystemColors.ControlLight;
            buttonJeans.Font = new Font("Bell MT", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            buttonJeans.Location = new Point(58, 261);
            buttonJeans.Name = "buttonJeans";
            buttonJeans.Size = new Size(125, 33);
            buttonJeans.TabIndex = 19;
            buttonJeans.Text = "Jeans";
            buttonJeans.UseVisualStyleBackColor = false;
            // 
            // buttonJacken
            // 
            buttonJacken.BackColor = SystemColors.ControlLight;
            buttonJacken.Font = new Font("Bell MT", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            buttonJacken.Location = new Point(58, 300);
            buttonJacken.Name = "buttonJacken";
            buttonJacken.Size = new Size(125, 33);
            buttonJacken.TabIndex = 20;
            buttonJacken.Text = "Jacken";
            buttonJacken.UseVisualStyleBackColor = false;
            // 
            // buttonHemden
            // 
            buttonHemden.BackColor = SystemColors.ControlLight;
            buttonHemden.Font = new Font("Bell MT", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            buttonHemden.Location = new Point(58, 339);
            buttonHemden.Name = "buttonHemden";
            buttonHemden.Size = new Size(125, 33);
            buttonHemden.TabIndex = 21;
            buttonHemden.Text = "Hemden";
            buttonHemden.UseVisualStyleBackColor = false;
            // 
            // buttonAccessoires
            // 
            buttonAccessoires.BackColor = SystemColors.ControlLight;
            buttonAccessoires.Font = new Font("Bell MT", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            buttonAccessoires.Location = new Point(58, 378);
            buttonAccessoires.Name = "buttonAccessoires";
            buttonAccessoires.Size = new Size(125, 33);
            buttonAccessoires.TabIndex = 22;
            buttonAccessoires.Text = "Accessoires";
            buttonAccessoires.UseVisualStyleBackColor = false;
            // 
            // pictureBox1
            // 
            pictureBox1.Location = new Point(336, 162);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(119, 171);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 23;
            pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            pictureBox2.Location = new Point(550, 162);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(119, 171);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 24;
            pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            pictureBox3.Location = new Point(767, 162);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(119, 171);
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 25;
            pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            pictureBox4.Location = new Point(337, 417);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(119, 171);
            pictureBox4.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox4.TabIndex = 26;
            pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            pictureBox5.Location = new Point(550, 417);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(119, 171);
            pictureBox5.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox5.TabIndex = 27;
            pictureBox5.TabStop = false;
            // 
            // pictureBox6
            // 
            pictureBox6.Location = new Point(767, 417);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(119, 171);
            pictureBox6.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox6.TabIndex = 28;
            pictureBox6.TabStop = false;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(336, 347);
            label2.Name = "label2";
            label2.Size = new Size(118, 25);
            label2.TabIndex = 29;
            label2.Text = "Jeans  39,99€";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(550, 347);
            label3.Name = "label3";
            label3.Size = new Size(134, 25);
            label3.TabIndex = 30;
            label3.Text = "Pullover 29,99€";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(767, 341);
            label4.Name = "label4";
            label4.Size = new Size(174, 25);
            label4.TabIndex = 31;
            label4.Text = "Regenmantel 50,00€";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(336, 602);
            label5.Name = "label5";
            label5.Size = new Size(120, 25);
            label5.TabIndex = 32;
            label5.Text = "Mütze 19,99€";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(550, 602);
            label6.Name = "label6";
            label6.Size = new Size(111, 25);
            label6.TabIndex = 33;
            label6.Text = "T-shirt 9,99€";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(767, 602);
            label7.Name = "label7";
            label7.Size = new Size(136, 25);
            label7.TabIndex = 34;
            label7.Text = "Top-Basic 9,99€";
            // 
            // button11
            // 
            button11.BackColor = SystemColors.ControlLight;
            button11.Font = new Font("Bell MT", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button11.Location = new Point(913, 653);
            button11.Name = "button11";
            button11.Size = new Size(125, 33);
            button11.TabIndex = 35;
            button11.Text = "weiter";
            button11.UseVisualStyleBackColor = false;
            // 
            // buttonKaufen
            // 
            buttonKaufen.BackColor = SystemColors.ControlLight;
            buttonKaufen.Font = new Font("Bell MT", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            buttonKaufen.Location = new Point(349, 378);
            buttonKaufen.Name = "buttonKaufen";
            buttonKaufen.Size = new Size(84, 33);
            buttonKaufen.TabIndex = 36;
            buttonKaufen.Text = "Kaufen";
            buttonKaufen.UseVisualStyleBackColor = false;
            buttonKaufen.Click += buttonKaufen_Click;
            // 
            // buttonKaufen1
            // 
            buttonKaufen1.BackColor = SystemColors.ControlLight;
            buttonKaufen1.Font = new Font("Bell MT", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            buttonKaufen1.Location = new Point(565, 378);
            buttonKaufen1.Name = "buttonKaufen1";
            buttonKaufen1.Size = new Size(84, 33);
            buttonKaufen1.TabIndex = 37;
            buttonKaufen1.Text = "Kaufen";
            buttonKaufen1.UseVisualStyleBackColor = false;
            // 
            // buttonKaufen2
            // 
            buttonKaufen2.BackColor = SystemColors.ControlLight;
            buttonKaufen2.Font = new Font("Bell MT", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            buttonKaufen2.Location = new Point(790, 378);
            buttonKaufen2.Name = "buttonKaufen2";
            buttonKaufen2.Size = new Size(84, 33);
            buttonKaufen2.TabIndex = 38;
            buttonKaufen2.Text = "Kaufen";
            buttonKaufen2.UseVisualStyleBackColor = false;
            // 
            // buttonKaufen3
            // 
            buttonKaufen3.BackColor = SystemColors.ControlLight;
            buttonKaufen3.Font = new Font("Bell MT", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            buttonKaufen3.Location = new Point(349, 642);
            buttonKaufen3.Name = "buttonKaufen3";
            buttonKaufen3.Size = new Size(84, 33);
            buttonKaufen3.TabIndex = 39;
            buttonKaufen3.Text = "Kaufen";
            buttonKaufen3.UseVisualStyleBackColor = false;
            // 
            // buttonKaufen4
            // 
            buttonKaufen4.BackColor = SystemColors.ControlLight;
            buttonKaufen4.Font = new Font("Bell MT", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            buttonKaufen4.Location = new Point(565, 642);
            buttonKaufen4.Name = "buttonKaufen4";
            buttonKaufen4.Size = new Size(84, 33);
            buttonKaufen4.TabIndex = 40;
            buttonKaufen4.Text = "Kaufen";
            buttonKaufen4.UseVisualStyleBackColor = false;
            // 
            // buttonKaufen5
            // 
            buttonKaufen5.BackColor = SystemColors.ControlLight;
            buttonKaufen5.Font = new Font("Bell MT", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            buttonKaufen5.Location = new Point(779, 642);
            buttonKaufen5.Name = "buttonKaufen5";
            buttonKaufen5.Size = new Size(84, 33);
            buttonKaufen5.TabIndex = 41;
            buttonKaufen5.Text = "Kaufen";
            buttonKaufen5.UseVisualStyleBackColor = false;
            // 
            // WebsideFenster
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ControlLight;
            ClientSize = new Size(1079, 704);
            Controls.Add(buttonKaufen5);
            Controls.Add(buttonKaufen4);
            Controls.Add(buttonKaufen3);
            Controls.Add(buttonKaufen2);
            Controls.Add(buttonKaufen1);
            Controls.Add(buttonKaufen);
            Controls.Add(button11);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(pictureBox6);
            Controls.Add(pictureBox5);
            Controls.Add(pictureBox4);
            Controls.Add(pictureBox3);
            Controls.Add(pictureBox2);
            Controls.Add(pictureBox1);
            Controls.Add(buttonAccessoires);
            Controls.Add(buttonHemden);
            Controls.Add(buttonJacken);
            Controls.Add(buttonJeans);
            Controls.Add(buttonKleider);
            Controls.Add(buttonTheNew);
            Controls.Add(buttonKinder);
            Controls.Add(buttonHerren);
            Controls.Add(buttonDamen);
            Controls.Add(button1);
            Controls.Add(buttonUEberUns);
            Controls.Add(buttonMeinKonto);
            Controls.Add(buttonEinkaufskorb);
            Controls.Add(VogueLabel);
            Controls.Add(label1);
            Name = "WebsideFenster";
            Text = "Webside";
            Load += WebsideFenster_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label VogueLabel;
        private Label label1;
        private Button buttonEinkaufskorb;
        private Button buttonMeinKonto;
        private Button buttonUEberUns;
        private Button button1;
        private Button buttonDamen;
        private Button buttonHerren;
        private Button buttonKinder;
        private Button buttonTheNew;
        private Button buttonKleider;
        private Button buttonJeans;
        private Button buttonJacken;
        private Button buttonHemden;
        private Button buttonAccessoires;
        private PictureBox pictureBox1;
        private PictureBox pictureBox2;
        private PictureBox pictureBox3;
        private PictureBox pictureBox4;
        private PictureBox pictureBox5;
        private PictureBox pictureBox6;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Button button11;
        private Button buttonKaufen;
        private Button buttonKaufen1;
        private Button buttonKaufen2;
        private Button buttonKaufen3;
        private Button buttonKaufen4;
        private Button buttonKaufen5;
    }
}