﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UrbanVogue_OnlineShop
{
    public class Zahlungen
    {
        public int ZahlungID {  get; set; }
        public int OrderID { get; set; }
        public int ZahlungsmethodeID { get; set; }
        public decimal Gesamtbetrag {  get; set; }

        public Zahlungen (int zahlungID, int orderID, int zahlungsmethodeID, decimal gesamtbetrag)
        {
            ZahlungID = zahlungID;
            OrderID = orderID;
            ZahlungsmethodeID = zahlungsmethodeID;
            Gesamtbetrag = gesamtbetrag;
        }
    }
}
