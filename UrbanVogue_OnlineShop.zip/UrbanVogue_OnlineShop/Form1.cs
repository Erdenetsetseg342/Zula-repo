using MySql.Data.MySqlClient;
using System.Drawing;

namespace UrbanVogue_OnlineShop
{
    public partial class Hauptfenster : Form
    {
        private Datenbank db;
        private List<Benutzer> benutzerList;
        private MySqlConnection con;
        private MySqlCommand comd;

        public Hauptfenster()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            db = new Datenbank();
            disBenutzer();

        }
        private void disBenutzer() // Anzeigen 
        {
            benutzerList = db.GetBenutzer(); // 
            textBoxBenutzer.Clear();
            foreach (Benutzer benuz in benutzerList) // diese Liste in unser List-box bringen 
            {
                Console.WriteLine(benuz.Name);
            }
        }

        private void buttonAnmelden_Click(object sender, EventArgs e)
        {
            string benutzername = textBoxBenutzer.Text;
            string passwort = textBoxPasswort.Text;

            string connString = "Server=localhost;Database=OnlineShopUrban;Uid=root;Pwd=;";
            using (MySqlConnection conn = new MySqlConnection(connString))
            {
                try
                {
                    conn.Open();
                    string query = "SELECT * FROM benutzer WHERE Name = @name AND Passwort = @passwort";
                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@name", benutzername);
                    cmd.Parameters.AddWithValue("@passwort", passwort);

                    MySqlDataReader reader = cmd.ExecuteReader();

                    if (reader.Read())  // Wenn der Benutzer existiert
                    {
                        MessageBox.Show("Anmeldung erfolgreich!", "Erfolg", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        this.Hide();
                        new WebsideFenster().Show(); // �ffnet das n�chste Fenster
                    }
                    else
                    {
                        MessageBox.Show("Falscher Benutzername oder Passwort!", "Fehler", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                    reader.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Fehler: " + ex.Message);
                }

            }
        }

        private void buttonUEberUns_Click(object sender, EventArgs e)
        {
            this.Hide();
            new Impressum_Ueber_Uns().Show(); // Hier wird das ueber nach Login ge�ffnet
        }

        private void buttonImpressum_Click(object sender, EventArgs e)
        {
            this.Hide();
            new Impressum_Ueber_Uns().Show(); // Hier wird das Impressum nach Login ge�ffnet
        }
    }
}
    

