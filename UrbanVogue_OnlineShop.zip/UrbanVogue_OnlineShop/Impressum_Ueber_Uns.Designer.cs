﻿namespace UrbanVogue_OnlineShop
{
    partial class Impressum_Ueber_Uns
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            VogueLabel = new Label();
            label1 = new Label();
            buttonEinkaufskorb = new Button();
            buttonMeinKonto = new Button();
            labelUeberUns = new Label();
            listBoxUeberUns = new ListBox();
            labelImpressum = new Label();
            listBox1 = new ListBox();
            button11 = new Button();
            SuspendLayout();
            // 
            // VogueLabel
            // 
            VogueLabel.AutoSize = true;
            VogueLabel.Font = new Font("Bell MT", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            VogueLabel.Location = new Point(62, 65);
            VogueLabel.Name = "VogueLabel";
            VogueLabel.Size = new Size(112, 41);
            VogueLabel.TabIndex = 3;
            VogueLabel.Text = "Vogue";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Bell MT", 20F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(31, 28);
            label1.Name = "label1";
            label1.Size = new Size(125, 46);
            label1.TabIndex = 2;
            label1.Text = "Urban";
            // 
            // buttonEinkaufskorb
            // 
            buttonEinkaufskorb.BackColor = SystemColors.ControlLight;
            buttonEinkaufskorb.Font = new Font("Bell MT", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            buttonEinkaufskorb.Location = new Point(820, 52);
            buttonEinkaufskorb.Name = "buttonEinkaufskorb";
            buttonEinkaufskorb.Size = new Size(158, 33);
            buttonEinkaufskorb.TabIndex = 4;
            buttonEinkaufskorb.Text = "EINKAUFSKORB";
            buttonEinkaufskorb.UseVisualStyleBackColor = false;
            // 
            // buttonMeinKonto
            // 
            buttonMeinKonto.BackColor = SystemColors.ControlLight;
            buttonMeinKonto.Font = new Font("Bell MT", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            buttonMeinKonto.Location = new Point(628, 52);
            buttonMeinKonto.Name = "buttonMeinKonto";
            buttonMeinKonto.Size = new Size(158, 33);
            buttonMeinKonto.TabIndex = 5;
            buttonMeinKonto.Text = "MEIN KONTO";
            buttonMeinKonto.UseVisualStyleBackColor = false;
            // 
            // labelUeberUns
            // 
            labelUeberUns.AutoSize = true;
            labelUeberUns.Font = new Font("Bell MT", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
            labelUeberUns.Location = new Point(31, 156);
            labelUeberUns.Name = "labelUeberUns";
            labelUeberUns.Size = new Size(86, 23);
            labelUeberUns.TabIndex = 6;
            labelUeberUns.Text = "Über uns";
            // 
            // listBoxUeberUns
            // 
            listBoxUeberUns.BackColor = SystemColors.ControlLight;
            listBoxUeberUns.Font = new Font("Bell MT", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
            listBoxUeberUns.FormattingEnabled = true;
            listBoxUeberUns.ItemHeight = 23;
            listBoxUeberUns.Location = new Point(31, 196);
            listBoxUeberUns.Name = "listBoxUeberUns";
            listBoxUeberUns.Size = new Size(960, 188);
            listBoxUeberUns.TabIndex = 7;
            listBoxUeberUns.SelectedIndexChanged += listBoxUeberUns_SelectedIndexChanged;
            // 
            // labelImpressum
            // 
            labelImpressum.AutoSize = true;
            labelImpressum.Font = new Font("Bell MT", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
            labelImpressum.Location = new Point(31, 425);
            labelImpressum.Name = "labelImpressum";
            labelImpressum.Size = new Size(103, 23);
            labelImpressum.TabIndex = 8;
            labelImpressum.Text = "Impressum";
            // 
            // listBox1
            // 
            listBox1.BackColor = SystemColors.ControlLight;
            listBox1.FormattingEnabled = true;
            listBox1.ItemHeight = 25;
            listBox1.Location = new Point(31, 462);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(382, 129);
            listBox1.TabIndex = 9;
            // 
            // button11
            // 
            button11.BackColor = SystemColors.ControlLight;
            button11.Font = new Font("Bell MT", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button11.Location = new Point(853, 588);
            button11.Name = "button11";
            button11.Size = new Size(125, 33);
            button11.TabIndex = 36;
            button11.Text = "Webside";
            button11.UseVisualStyleBackColor = false;
            // 
            // Impressum_Ueber_Uns
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ControlLight;
            ClientSize = new Size(1034, 661);
            Controls.Add(button11);
            Controls.Add(listBox1);
            Controls.Add(labelImpressum);
            Controls.Add(listBoxUeberUns);
            Controls.Add(labelUeberUns);
            Controls.Add(buttonMeinKonto);
            Controls.Add(buttonEinkaufskorb);
            Controls.Add(VogueLabel);
            Controls.Add(label1);
            Name = "Impressum_Ueber_Uns";
            Text = "Impressum_Ueber_Uns";
            Load += Impressum_Ueber_Uns_Load_1;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label VogueLabel;
        private Label label1;
        private Button buttonEinkaufskorb;
        private Button buttonMeinKonto;
        private Label labelUeberUns;
        private ListBox listBoxUeberUns;
        private Label labelImpressum;
        private ListBox listBox1;
        private Button button11;
    }
}