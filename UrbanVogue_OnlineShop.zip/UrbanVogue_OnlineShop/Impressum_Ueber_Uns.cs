﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UrbanVogue_OnlineShop
{
    public partial class Impressum_Ueber_Uns : Form
    {
        public Impressum_Ueber_Uns()
        {
            InitializeComponent();

        }

        private void Impressum_Ueber_Uns_Load_1(object sender, EventArgs e)
        {
            listBoxUeberUns.Items.Add("Willkommen bei Urban Vogue, deinem Online-Shop für stylische und moderne Bekleidung!");
            Console.WriteLine();
            listBoxUeberUns.Items.Add("Wir bieten eine große Auswahl an hochwertigen und trendigen Kleidungsstücken.");
            listBoxUeberUns.Items.Add("Egal, ob du Streetwear, elegante Abendmode oder bequeme Alltagskleidung suchst – bei uns wirst du fündig!");
            listBoxUeberUns.Items.Add("Unser Ziel ist es, Mode mit Qualität und Stil zu verbinden, damit du dich in jedem Outfit wohlfühlst. ");
            listBoxUeberUns.Items.Add("Mit schnellen Lieferzeiten, sicheren Zahlungsmethoden und erstklassigem Kundenservice sorgen wir für");
            listBoxUeberUns.Items.Add("ein rundum gelungenes Einkaufserlebnis. ");
            Console.WriteLine();
            listBoxUeberUns.Items.Add("Entdecke jetzt die neuesten Trends und werde Teil unserer Fashion-Community!");
        }
        private void listBoxUeberUns_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(labelUeberUns.Text = ""))
            {
                labelUeberUns.Text = "Willkommen bei Urban Vogue, deinem Online-Shop für stylische und moderne Bekleidung! " +
                    "Wir bieten eine große Auswahl an hochwertigen und trendigen Kleidungsstücken für jede Gelegenheit. " +
                    "Egal, ob du lässige Streetwear, elegante Abendmode oder bequeme Alltagskleidung suchst – bei uns wirst du fündig. " +
                    "Unser Ziel ist es, Mode mit Qualität und Stil zu verbinden, damit du dich in jedem Outfit wohlfühlst. " +
                    "Mit schnellen Lieferzeiten, sicheren Zahlungsmethoden und erstklassigem Kundenservice sorgen wir für ein " +
                    "rundum gelungenes Einkaufserlebnis. " +
                    "Entdecke jetzt die neuesten Trends und werde Teil unserer Fashion-Community!";

            }
        }


    }
}
