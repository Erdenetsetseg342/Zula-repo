﻿using Org.BouncyCastle.Asn1.BC;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UrbanVogue_OnlineShop
{
    public partial class WebsideFenster : Form
    {
        private int index = 0;
        private string[] kleiderBilder =
        {
            "C:\\Mist\\Gini1.jpg",
            "C:\\Mist\\Leon.jpg",
            "C:\\Mist\\Leto.jpg",
        };
        private List<string> warenkorb = new List<string>(); // Liste für Produkte
        private double gesamtPreis = 0.0;

        public WebsideFenster()
        {
            InitializeComponent();
        }
        private void buttonKaufen_Click(object sender, EventArgs e)
        {

            Button btn = sender as Button;
            if (btn != null) return;
            // Produkt aus Button_Daten abrufen 
            string produkt = btn.Tag.ToString();
            double preis = Convert.ToDouble(btn.AccessibleDescription);
            // Produkt zur Warenkorb-Liste hinzufügen
            string eintrag = $" {produkt} + {preis}";
            warenkorb.Add(eintrag);
            listBoxWarenkorb.Items.Add(eintrag);

            MessageBox.Show($"{produkt} wurde zum Warenkorb hinzugefügt!", "Erfolg", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        private void WebsideFenster_Load(object sender, EventArgs e)
        {
            // Automatisch Kaufen-Buttons mit Produktdaten verbinden
            ProduktHinzufuegen("Jeans", 39.99, buttonKaufen);
            ProduktHinzufuegen("Pullover", 29.99, buttonKaufen1);
            ProduktHinzufuegen("Regenmantel", 50.00, buttonKaufen2);
            ProduktHinzufuegen("Mütze", 19.99, buttonKaufen3);
            ProduktHinzufuegen("T-Shirt", 9.99, buttonKaufen4);
            ProduktHinzufuegen("Top-Basic", 9.99, buttonKaufen5);
        }
        private void ProduktHinzufuegen(string produkt, double preis, Button btn)
        {
            btn.Tag = produkt;
            btn.AccessibleDescription = preis.ToString();
            btn.Click += buttonKaufen_Click;
        }
        private void buttonEinkaufskorb_Click(object sender, EventArgs e)
        {
            // Neues Fenster (Warenkorb) öffnen und Warenkorb-Liste übergeben
            this.Hide();
            new Zahlungen().Show();
        }
        private void buttonDamen_Click(object sender, EventArgs e)
        {
            if (kleiderBilder.Length > 0)
            {
                pictureBox1.ImageLocation = kleiderBilder[index];
                pictureBox2.ImageLocation = kleiderBilder[index + 1];
                pictureBox3.ImageLocation = kleiderBilder[index + 1];
                index = (index + 1) % kleiderBilder.Length;
            }

        }
    }



}
